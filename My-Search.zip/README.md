# My-Search
A minimal Search Page Layout with Actual Functions <a href="https://aanas.rf.gd">Demo Link</a>
  <div style="display: flex;">
        <img src="https://github.com/user-attachments/assets/23f554a7-adf1-4756-828e-fcbbf66c0645" alt="" width="75%">
        <img src="https://github.com/user-attachments/assets/c0c04528-dfde-418d-b2dc-f4b367cccff1" alt="" height="350px" >
    </div>
